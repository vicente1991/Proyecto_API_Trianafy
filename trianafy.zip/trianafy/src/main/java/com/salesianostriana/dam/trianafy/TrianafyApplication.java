package com.salesianostriana.dam.trianafy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrianafyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrianafyApplication.class, args);
	}

}
