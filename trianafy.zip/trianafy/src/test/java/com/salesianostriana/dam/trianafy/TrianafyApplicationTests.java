package com.salesianostriana.dam.trianafy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrianafyApplicationTests {

	@Test
	void contextLoads() {
	}

}
